export interface Hero {
    _id: number;
    name: string;
}